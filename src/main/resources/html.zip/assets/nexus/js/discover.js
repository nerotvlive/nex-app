function initDiscover() {
    highlight(document.getElementById("discover-button"));
    document.querySelector(".menu-panel").querySelector(".card-body").innerHTML = "<i onclick='window.open(`https://discord.gg/hbHDrqUjJ8`,`_blank`);' class='bi bi-discord'></i><i onclick='window.open(`https://github.com/nerotvlive/nex-app`,`_blank`);' class='bi bi-github'></i><i onclick='console.log(`[CONNECTOR] exit`)' class='bi bi-door-open'></i>";
    const urlParams = new URLSearchParams(window.location.search);
    if(urlParams.has("q")) {
        loadPage("search.html",false,"?q="+urlParams.get("q"));
    } else if(urlParams.has("dt")) {
        if(urlParams.get("dt")==="search") {
            loadPage("search.html",false);
        }
    }
}