function initDashboard() {

}